const fs = require('fs');
const vm = require('vm');
const assert = require('assert/strict');
const path = require('path');
class Base {}
class TAbstractFile {}
class TFile extends TAbstractFile {
  constructor(p) { super(); this.path = p; this.name = p.split('/').pop(); this.extension = this.name.split('.').pop(); this.basename = this.name.slice(0, -this.extension.length - 1); this.stat = {ctime: 0}; }
}
class TFolder extends TAbstractFile { constructor(p, vault) { super(); this.path = p; this.vault = vault; } }
async function run(filename) {
  const settings = JSON.parse(fs.readFileSync(path.join(__dirname, '../plugins/attachment-management/data.json'), 'utf8'));
  const files = new Map();
  const moves = [];
  const note = new TFile('Note.md');
  const pdf = new TFile('Chờ/Ảnh/report.pdf');
  const png = new TFile('Chờ/Ảnh/test.png');
  const vault = {
    getAbstractFileByPath: p => files.get(p) || null,
    getFiles: () => [...files.values()].filter(f => f instanceof TFile),
    getConfig: () => 'Chờ/Ảnh',
    async createFolder(p) { const f = new TFolder(p, vault); files.set(p, f); return f; },
    adapter: {
      async exists(p) { return files.has(p); },
      async mkdir(p) { await vault.createFolder(p); },
      async readBinary(p) { return new TextEncoder().encode(p.split('/').pop()).buffer; },
      async list(p) { return {files: [...files.keys()].filter(k => k.startsWith(p + '/') && files.get(k) instanceof TFile)}; }
    }
  };
  for (const f of [note, pdf, png]) files.set(f.path, f);
  const app = {vault, metadataCache: {resolvedLinks: {'Note.md': {[pdf.path]: 1, [png.path]: 1}}}, fileManager: {async renameFile(file, dst) { files.delete(file.path); file.path = dst; files.set(dst, file); moves.push(dst); }}};
  const obsidian = {Plugin: Base, PluginSettingTab: Base, Modal: Base, TAbstractFile, TFile, TFolder, debounce: fn => fn, normalizePath: p => p};
  const ctx = {module: {exports: {}}, console, app, window: {moment: () => ({format: () => '20261010'})}, require: () => obsidian};
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(filename, 'utf8'), ctx);
  const handler = new ctx.ArrangeHandler(settings, app);
  await handler.rearrangeAttachment(1);
  assert.deepEqual(moves, ['Tai lieu/PDF/report.pdf']);
  assert.equal(png.path, 'Chờ/Ảnh/test.png');
  await handler.rearrangeAttachment(1);
  assert.equal(moves.length, 1, 'Must not rename again on repeat');

  // Real import handler: blocked first item, several drops, delayed I/O and reentrant events.
  let noteContent = '';
  let saveCount = 0;
  vault.cachedRead = async () => noteContent;
  vault.adapter.process = async (p, fn) => { noteContent = fn(noteContent); };
  vault.rename = async (file, dst) => {
    await new Promise(resolve => setTimeout(resolve, 5));
    assert.ok(!files.has(dst), 'Must not overwrite an existing destination');
    files.delete(file.path); file.path = dst; files.set(dst, file); moves.push(dst);
  };
  app.fileManager.generateMarkdownLink = file => '[[' + file.path + ']]';
  app.workspace = {getActiveViewOfType: () => null};
  const plugin = new ctx.module.exports.default();
  plugin.app = app;
  plugin.settings = settings;
  plugin.saveData = async () => { saveCount++; };
  const orphan = new TFile('Chờ/Ảnh/unlinked.pdf');
  const a = new TFile('Chờ/Ảnh/first.pdf');
  const b = new TFile('Chờ/Ảnh/second.pdf');
  for (const f of [orphan, a, b]) files.set(f.path, f);
  plugin.createdQueue = [orphan, a, b];
  noteContent = '![[Chờ/Ảnh/first.pdf]] ![[Chờ/Ảnh/second.pdf]]';
  await Promise.all([plugin.processCreatedAttachments(note), plugin.processCreatedAttachments(note)]);
  assert.equal(a.path, 'Tai lieu/PDF/first.pdf');
  assert.equal(b.path, 'Tai lieu/PDF/second.pdf');
  assert.equal(plugin.createdQueue.length, 1);
  const c = new TFile('Chờ/Ảnh/third.pdf');
  files.set(c.path, c);
  plugin.createdQueue.push(c);
  noteContent += ' ![[Chờ/Ảnh/third.pdf]]';
  await plugin.processCreatedAttachments(note);
  assert.equal(c.path, 'Tai lieu/PDF/third.pdf');
  assert.equal(saveCount, 3);
  assert.ok(noteContent.includes('[[Tai lieu/PDF/third.pdf]]'));
}
(async () => {
  await assert.rejects(run(path.join(__dirname, 'main.before-pdf-fix.js')), /Tai lieu\/PDF\/report.pdf/);
  await run(path.join(__dirname, '../plugins/attachment-management/main.js'));
  console.log('PASS: original regression, PDF path/name, excluded image, repeated arrange, unlinked queue head, multiple imports, concurrent events, subsequent import and link updates.');
})().catch(e => { console.error(e); process.exitCode = 1; });
