const fs = require('fs');
const path = require('path');
const vm = require('vm');
const target = path.join(__dirname, '../plugins/attachment-management/main.js');
let s = fs.readFileSync(target, 'utf8');
function between(start, end, replacement) {
  const a = s.indexOf(start), b = s.indexOf(end, a);
  if (a < 0 || b < 0) throw new Error('Missing patch boundary');
  s = s.slice(0,a) + replacement + s.slice(b);
}
s = s.replace('  processAttach(attach, source) {', '  async processAttach(attach, source) {');
between('    metadata.getAttachFileName(setting, this.settings.dateFormat, attach, this.app.vault.adapter).then', '\n  /**\n   * Rename the file specified', `    const attachName = await metadata.getAttachFileName(setting, this.settings.dateFormat, attach, this.app.vault.adapter) + "." + attach.extension;
    if (attach.path === (0, import_obsidian11.normalizePath)(path.join(attachPath, attachName))) return;
    if (!await this.app.vault.adapter.exists(attachPath, true)) {
      await this.app.vault.createFolder(attachPath);
    }
    const attachPathFolder = this.app.vault.getAbstractFileByPath(attachPath);
    const { name } = await deduplicateNewName(attachName, attachPathFolder);
    await this.renameCreateFile(attach, attachPath, name, source);
  }
`);
between('  renameCreateFile(attach, attachPath, attachName, source) {', '\n  /**\n   * Update the old link', `  async renameCreateFile(attach, attachPath, attachName, source) {
    const dst = (0, import_obsidian11.normalizePath)(path.join(attachPath, attachName));
    const name = attach.name;
    const originalBasename = attach.basename;
    const oldLink = this.app.fileManager.generateMarkdownLink(attach, source.path);
    await this.app.vault.rename(attach, dst);
    if (name !== attachName) queueRenameNotice(name, attachName);
    const newLink = this.app.fileManager.generateMarkdownLink(attach, source.path);
    await this.updateLinkInSource(source, oldLink, newLink);
    const { setting } = getOverrideSetting(this.settings, source);
    const md5 = await md5sum(this.app.vault.adapter, attach);
    saveOriginalName(this.settings, setting, attach.extension, { n: originalBasename, md5 });
    await this.plugin.saveData(this.settings);
  }
`);
s = s.replace('    this.app.vault.adapter.process(source.path, (data) => {', '    return this.app.vault.adapter.process(source.path, (data) => {');
between('          const curentTime =', '            return;', `          if (isMarkdownFile(file.extension) || isCanvasFile(file.extension)) {
`);
s = s.replace('          this.createdQueue.push(file);', `          this.createdQueue.push(file);
          const activeFile = getActiveFile(this.app);
          if (activeFile) this.processCreatedAttachments(activeFile);`);
between('          debugLog("on modify event - create queue:",', '\n        })\n      );', '          this.processCreatedAttachments(file);');
const marker = '  async overrideConfiguration(file, setting) {';
s = s.replace(marker, `  processCreatedAttachments(source) {
    if (!(source instanceof import_obsidian12.TFile) || !["md", "canvas"].includes(source.extension) || !this.createdQueue.length) return Promise.resolve();
    // Serialize imports and inspect the entire queue: an unlinked file cannot block later files.
    this.attachmentWork = (this.attachmentWork || Promise.resolve()).then(async () => {
      const data = await this.app.vault.cachedRead(source);
      for (const attachment of [...this.createdQueue]) {
        if (!await this.app.vault.adapter.exists(attachment.path, true)) {
          this.createdQueue = this.createdQueue.filter(item => item !== attachment);
          continue;
        }
        const link = this.app.fileManager.generateMarkdownLink(attachment, source.path);
        if (!(source.extension === "md" ? data.includes(link) : data.includes(attachment.path))) continue;
        try {
          await new CreateHandler(this, this.settings).processAttach(attachment, source);
          this.createdQueue = this.createdQueue.filter(item => item !== attachment);
        } catch (error) {
          console.error("Attachment Management: import failed", error);
          new import_obsidian12.Notice(t("notices.error.unknownError") + ": " + (error?.message || error));
        }
      }
    }).catch(error => console.error("Attachment Management: queue failed", error));
    return this.attachmentWork;
  }
` + marker);
new vm.Script(s);
fs.writeFileSync(target, s);
console.log('Applied sequential import queue and awaited folder/file operations.');
