const fs = require('fs');
const vm = require('vm');
const assert = require('assert/strict');
let languageToggle;
class Base {}
class Plugin {
  constructor() { this.manifest = {name: 'Attachment Management'}; }
  async loadData() { return this.saved || {dateFormat: 'YYYY-MM-DD', excludedPaths: 'Keep'}; }
  async saveData(data) { this.saved = JSON.parse(JSON.stringify(data)); }
  addCommand(command) { return {...command, name: this.manifest.name + ': ' + command.name}; }
}
class Setting {
  setName() { return this; }
  setDesc() { return this; }
  addToggle(cb) {
    cb({setValue(value) { assert.equal(value, true); return this; }, onChange(fn) { languageToggle = fn; }});
    throw new Error('LANGUAGE_ROW_RENDERED');
  }
}
const context = {module: {exports: {}}, console, require: () => ({Plugin, PluginSettingTab: Base, Modal: Base, Setting, debounce: fn => fn})};
vm.createContext(context);
vm.runInContext(fs.readFileSync(require('path').join(__dirname, '../plugins/attachment-management/main.js'), 'utf8'), context);
function leaves(obj, prefix = '') {
  return Object.entries(obj).flatMap(([key, value]) => typeof value === 'string' ? [[prefix + key, value]] : leaves(value, prefix + key + '.'));
}
(async () => {
  context.initI18n('vi');
  const vi = new Map(leaves(context.vi));
  const placeholders = s => [...s.matchAll(/\$?\{[^}]+\}/g)].map(m => m[0]).sort();
  for (const [key, value] of leaves(context.en)) {
    assert.ok(vi.has(key), 'Missing Vietnamese: ' + key);
    assert.deepEqual(placeholders(value), placeholders(vi.get(key)), 'Changed variables: ' + key);
  }
  assert.equal(context.t('notices.fileRenamed', {from: 'a.png', to: 'b.png'}), 'Đã đổi tên a.png thành b.png');
  const plugin = new context.module.exports.default();
  await plugin.loadSettings();
  assert.equal(plugin.settings.language, 'vi');
  plugin.initCommands();
  assert.equal(plugin.localizedCommands.length, 5);
  const tab = new context.AttachmentManagementSettingTab({}, plugin);
  tab.containerEl = {empty() {}, createEl() {}};
  assert.throws(() => tab.display(), /LANGUAGE_ROW_RENDERED/);
  tab.display = () => {};
  await languageToggle(false);
  assert.equal(context.t('common.cancel'), 'Cancel');
  assert.equal(plugin.saved.language, 'en');
  assert.equal(plugin.localizedCommands[0].command.name, 'Attachment Management: Rearrange all linked attachments');
  await plugin.loadSettings();
  assert.equal(plugin.settings.language, 'en');
  await languageToggle(true);
  assert.equal(context.t('common.cancel'), 'Hủy');
  assert.equal(plugin.saved.language, 'vi');
  assert.equal(plugin.saved.dateFormat, 'YYYY-MM-DD');
  assert.equal(plugin.saved.excludedPaths, 'Keep');
  console.log('PASS: all ' + vi.size + ' locale strings, variables, five commands, VI/EN switch, persistence, existing settings.');
})().catch(error => {console.error(error); process.exitCode = 1;});
