const fs = require('fs');
const path = require('path');
const vm = require('vm');
const dir = path.resolve(__dirname, '../plugins/attachment-management');
const target = path.join(dir, 'main.js');
let source = fs.readFileSync(target, 'utf8');
if (source.includes('// Local Vietnamese translation')) throw new Error('Already patched');
const backup = path.join(__dirname, 'backup-0.12.1');
fs.mkdirSync(backup, { recursive: true });
for (const file of ['main.js', 'manifest.json', 'styles.css', 'data.json']) {
  if (fs.existsSync(path.join(dir, file)) && !fs.existsSync(path.join(backup, file)))
    fs.copyFileSync(path.join(dir, file), path.join(backup, file));
}
const vi = {
  common: { cancel: 'Hủy' },
  settings: {
    title: 'Cài đặt quản lý tệp đính kèm',
    language: { name: 'Ngôn ngữ / Language — VI / EN', desc: 'Bật: Tiếng Việt (VI). Tắt: English (EN).' },
    rootPath: { name: 'Vị trí gốc lưu tệp đính kèm', desc: 'Chọn vị trí gốc để lưu tệp đính kèm', options: { obsidian: 'Dùng cài đặt của Obsidian', inFolder: 'Trong thư mục được chỉ định bên dưới', nextToNote: 'Cạnh ghi chú, trong thư mục được chỉ định bên dưới' } },
    rootFolder: { name: 'Thư mục gốc', desc: 'Thư mục gốc để lưu tệp đính kèm mới' },
    attachmentPath: { name: 'Đường dẫn tệp đính kèm', desc: 'Đường dẫn trong thư mục gốc. Các biến có thể dùng: ${notepath}, ${notename}, ${parent}' },
    attachmentFormat: { name: 'Mẫu tên tệp đính kèm', desc: 'Quy định cách đặt tên tệp đính kèm. Các biến có thể dùng: ${date}, ${notename}, ${md5} và ${originalname}.' },
    dateFormat: { name: 'Định dạng ngày giờ', desc: 'Định dạng ngày giờ theo Moment', linkText: 'Các tùy chọn định dạng Moment' },
    autoRename: { name: 'Tự động đổi tên tệp đính kèm', desc: 'Tự động đổi tên thư mục hoặc tệp đính kèm khi bạn đổi tên ghi chú Markdown/Canvas tương ứng hoặc thư mục chứa ghi chú đó.' },
    extensionOverride: { name: 'Cài đặt riêng theo phần mở rộng', desc: 'Đặt quy tắc đổi tên riêng cho tệp đính kèm có phần mở rộng cụ thể (ví dụ: pdf hoặc zip).', addButton: 'Thêm cài đặt riêng theo phần mở rộng', extension: { name: 'Phần mở rộng', desc: 'Phần mở rộng cần áp dụng cài đặt riêng', placeholder: 'pdf|docx?' }, tooltips: { remove: 'Xóa cài đặt riêng', edit: 'Sửa cài đặt riêng', save: 'Lưu cài đặt riêng' }, saveNotice: 'Đã lưu cài đặt riêng theo phần mở rộng' },
    excludeExtension: { name: 'Mẫu phần mở rộng cần loại trừ', desc: 'Biểu thức chính quy để loại trừ các phần mở rộng không cần xử lý.', placeholder: 'pdf|docx?|xlsx?|pptx?|zip|rar' },
    excludedPaths: { name: 'Đường dẫn cần loại trừ', desc: 'Nhập đường dẫn đầy đủ của các thư mục không cần đổi tên, phân biệt chữ hoa/thường và không có dấu / ở đầu. Phân cách các đường dẫn bằng dấu chấm phẩy (;).' },
    excludeSubpaths: { name: 'Loại trừ cả thư mục con', desc: 'Bật để loại trừ tất cả thư mục con của các đường dẫn được liệt kê ở trên.' }
  },
  override: { title: 'Cài đặt riêng', menuTitle: 'Cài đặt riêng cho tệp đính kèm', addExtensionOverrides: 'Thêm cài đặt riêng theo phần mở rộng', extension: { name: 'Phần mở rộng', desc: 'Phần mở rộng cần áp dụng cài đặt riêng', placeholder: 'pdf' }, buttons: { reset: 'Đặt lại', submit: 'Áp dụng' }, notifications: { reset: 'Đã đặt lại cài đặt tệp đính kèm của {path}', overridden: 'Đã áp dụng cài đặt riêng cho tệp đính kèm của {path}' } },
  extensionOverride: { title: 'Cài đặt riêng theo phần mở rộng', rootPath: { name: 'Vị trí gốc lưu tệp đính kèm', desc: 'Chọn vị trí gốc cho tệp có phần mở rộng này' }, rootFolder: { name: 'Thư mục gốc', desc: 'Thư mục gốc cho tệp có phần mở rộng này' }, attachmentPath: { name: 'Đường dẫn tệp đính kèm', desc: 'Đường dẫn trong thư mục gốc cho tệp có phần mở rộng này' }, attachmentFormat: { name: 'Mẫu tên tệp đính kèm', desc: 'Quy định cách đặt tên tệp có phần mở rộng này' }, buttons: { save: 'Lưu' } },
  confirm: { title: 'Xác nhận', message: 'Thao tác này đang trong giai đoạn thử nghiệm và không thể hoàn tác. Hãy sao lưu kho ghi chú trước! Bạn có chắc muốn tiếp tục?', continue: 'Tiếp tục' },
  notices: { fileExcluded: 'Đã loại trừ {path}', overrideRemoved: 'Đã xóa cài đặt riêng của {path}', fileRenamed: 'Đã đổi tên {from} thành {to}', filesRenamedBatch: 'Đã đổi tên {count} tệp đính kèm', arrangeCompleted: 'Đã sắp xếp xong', resetAttachmentSetting: 'Đã đặt lại cài đặt tệp đính kèm của {path}', error: { unknownError: 'Đã xảy ra lỗi không xác định' } },
  commands: { rearrangeAllLinks: 'Sắp xếp lại tất cả tệp đính kèm được liên kết', rearrangeActiveLinks: 'Sắp xếp lại tệp đính kèm được liên kết trong ghi chú hiện tại', overrideSetting: 'Áp dụng cài đặt riêng', resetOverrideSetting: 'Đặt lại cài đặt riêng', clearUnusedStorage: 'Xóa dữ liệu tên gốc không còn sử dụng' },
  errors: { canvasNotSupported: 'Không hỗ trợ cài đặt riêng cho phần mở rộng Canvas.', markdownNotSupported: 'Không hỗ trợ cài đặt riêng cho phần mở rộng Markdown.', extensionEmpty: 'Phần mở rộng áp dụng cài đặt riêng không được để trống.', duplicateExtension: 'Phần mở rộng áp dụng cài đặt riêng đã tồn tại.', excludedExtension: 'Không thể áp dụng cài đặt riêng cho phần mở rộng đã bị loại trừ.', attachFormatEmpty: 'Mẫu tên tệp đính kèm không được để trống.', attachFormatIllegalChar: 'Mẫu tên tệp đính kèm chứa ký tự không hợp lệ: {char}', attachFormatUnknownVariable: 'Biến không xác định trong mẫu tên tệp đính kèm: {name}', attachmentPathEmpty: 'Đường dẫn tệp đính kèm không được để trống.', attachmentPathIllegalChar: 'Đường dẫn tệp đính kèm chứa ký tự không hợp lệ: {char}', attachmentPathUnknownVariable: 'Biến không xác định trong đường dẫn tệp đính kèm: {name}' }
};
function replaceOnce(from, to) {
  if (source.split(from).length !== 2) throw new Error('Expected one match: ' + from);
  source = source.replace(from, () => to);
}
replaceOnce('var currentLanguage = "en";', '// Local Vietnamese translation\nvar vi = ' + JSON.stringify(vi, null, 2) + ';\nen.settings.language = { name: "Language / Ngôn ngữ — VI / EN", desc: "On: Tiếng Việt (VI). Off: English (EN)." };\nen.commands.overrideSetting = "Overriding setting";\nvar currentLanguage = "en";');
replaceOnce('  en: {},', '  vi,\n  en: {},');
replaceOnce('var DEFAULT_SETTINGS = {', 'var DEFAULT_SETTINGS = {\n  language: "vi",');
replaceOnce('    initI18n();', '    initI18n(this.settings.language);');
replaceOnce('    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());', '    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());\n    this.settings.language = this.settings.language === "en" ? "en" : "vi";');
replaceOnce('    containerEl.createEl("h2", { text: t("settings.title") });', `    containerEl.createEl("h2", { text: t("settings.title") });
    new import_obsidian4.Setting(containerEl)
      .setName(t("settings.language.name"))
      .setDesc(t("settings.language.desc"))
      .addToggle(toggle => toggle.setValue(this.plugin.settings.language === "vi").onChange(async enabled => {
        this.plugin.settings.language = enabled ? "vi" : "en";
        setLanguage(this.plugin.settings.language);
        for (const { command, key } of this.plugin.localizedCommands || []) {
          command.name = this.plugin.manifest.name + ": " + t(key);
        }
        this.display();
        await this.plugin.saveSettings();
      }));`);
replaceOnce('      name: "Overriding setting",', '      name: t("commands.overrideSetting"),');
// Keep the registered command objects so their labels also change immediately.
replaceOnce('  initCommands() {', `  addLocalizedCommand(command, key) {
    const registered = this.addCommand(command);
    (this.localizedCommands || (this.localizedCommands = [])).push({ command: registered || command, key });
  }
  initCommands() {`);
source = source.replace(/this\.addCommand\(\{(\s+id: [^\n]+\n\s+name: t\("(commands\.[^"]+)"\),[\s\S]*?)\n    \}\);/g, 'this.addLocalizedCommand({$1\n    }, "$2");');
new vm.Script(source);
fs.writeFileSync(target, source, 'utf8');
console.log('Installed Vietnamese locale and persistent VI/EN switch.');
